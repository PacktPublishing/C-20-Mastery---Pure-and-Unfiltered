int GetValue(int v) {
	return v * 2 ;
}
constinit int a = GetValue(5) ;