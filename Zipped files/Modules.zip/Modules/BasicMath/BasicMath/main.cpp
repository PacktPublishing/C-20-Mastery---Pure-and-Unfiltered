#include <iostream>

#include "basic_math.h"

int main() {
	auto sum = Add(3,5) ;
	std::cout << sum << '\n' ;
}
