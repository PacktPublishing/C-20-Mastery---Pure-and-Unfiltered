#include "basic_math.h"
int Add(int x, int y) {
	return x + y ;
}
