#pragma once
int Add(int x,int y) ;
