import poash.basicmath ;
#include <iostream>
//import std.core;

int main() {
	auto result = Add(3,5) ;
	std::cout << result <<'\n' ;
	std::cout << "Area is : " << CircleAlgorithms::Area(8.2) << '\n' ;
}
