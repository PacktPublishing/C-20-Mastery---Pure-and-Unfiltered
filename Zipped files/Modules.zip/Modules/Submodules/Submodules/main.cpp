//import poash.math;
import poash.geom_math;
#include <iostream>

int main() {
	//std::cout << "Sum:" << Add(2,3) << '\n' ;
	std::cout << "Circle Area:" << CircleArea(3.5) << '\n' ;
	//Utils utils ;
	//utils.Foo() ;
}
