module basic_math ;
namespace Math {
	int Add(int x,int y) {
		return x + y ;
	}
}
