import basic_math ;
#include <iostream>

int main() {
	using namespace Math ;
	std::cout << "Sum is:" << Add(5,2) << '\n' ;
}