import basic.math ;
#include <iostream>

int main() {
	auto result = Add(3,5) ;
	std::cout << result <<'\n' ;
	std::cout << "Area is : " << CircleAlgorithms::Area(8.2) << '\n' ;
}
